import tweepy

# Twitter API credentials
API_KEY = 'ifQGGpA1WhIPm1L0l1gOQAfjZ'
API_SECRET_KEY = 'ALqzxUwUrVAxQPCEOCBvwwApxIv0iUxMyuFwi9Q5ivn6adNczZ'
ACCESS_TOKEN = '1766125742893735936-rOiQIWJzDjzS01jHaH5lvLcC1jDsnI'
ACCESS_TOKEN_SECRET = 'MIMwfrv47qNOXvEQD8lxvpMxTRmZyPLThSZQEsJUrrCC6'

# Authenticate with Twitter API
auth = tweepy.OAuth1UserHandler(API_KEY, API_SECRET_KEY, ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
api = tweepy.API(auth)

# Tweet "Hello, Twitter!"
api.update_status("Hello, Twitter!")
