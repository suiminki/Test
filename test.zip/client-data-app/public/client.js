function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    // Send a POST request to the server to validate the login credentials
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    })
    .then(response => {
        if (response.ok) {
            // If login successful, set the loggedInUser variable
            return response.json().then(data => {
                loggedInUser = data.username;// Set loggedInUser
                document.getElementById("loginForm").style.display = "none";
                document.getElementById("userInfo").style.display = "block";
                document.getElementById("loggedInUser").innerText = loggedInUser;
                document.getElementById("logoutBtn").style.display = "block";
                document.getElementById("deleteBtn").style.display = "block";
            });
        } else {
            // If login failed, display error message
            return response.json().then(error => {
                throw new Error(error.error);
            });
        }
    })
    .catch(error => {
        alert(error.message);
    });
}

function logout() {
    // Hide user info and show login form
    document.getElementById("loginForm").style.display = "block";
    document.getElementById("userInfo").style.display = "none";
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
}

function deleteAccount() {
    // Confirm with the user before proceeding with account deletion
    if (confirm("Are you sure you want to delete your account?")) {
        // Send a DELETE request to the server to delete the user account
        fetch('/account', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username: loggedInUser }),
            body: JSON.stringify({ password: loggedInUser }), // Send the logged-in username
        })
        .then(response => {
            if (response.ok) {
                // If the request is successful, log out the user
                logout();
                alert("Account deleted successfully!");
            } else {
                // If there's an error, display an error message
                alert("Error deleting account. Please try again later.");
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.'); // Display an error message
        });
    }
}

function showSignupForm() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
}

function showLoginForm() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
}

function signup() {
    var username = document.getElementById("signupUsername").value;
    var email = document.getElementById("signupEmail").value;
    var password = document.getElementById("signupPassword").value;

    // Make sure the username, email, and password are not empty
    if (!username || !email || !password) {
        alert("Please fill in all fields");
        return;
    }

    // Send a POST request to the server with the signup data
    fetch('/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, email, password }),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message); // Display a success message
        // Hide the signup form and show the login form
        document.getElementById("signupForm").style.display = "none";
        document.getElementById("loginForm").style.display = "block";
        // Optionally, you can reset the login form fields
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.'); // Display an error message
    });
}

// Function to retrieve the logged-in user ID
function getLoggedInUserId() {
    // Replace this with your logic to retrieve the logged-in user ID
    // For demonstration purposes, let's assume there's a variable named loggedInUser that stores the user ID
    return loggedInUser; // Return the logged-in user ID
}
