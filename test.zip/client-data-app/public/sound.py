import numpy as np
from scipy.io.wavfile import write

def generate_white_noise(duration_sec, sample_rate):
    num_samples = int(duration_sec * sample_rate)
    white_noise = np.random.uniform(-1, 1, num_samples)
    return white_noise

if __name__ == "__main__":
    duration_sec = 10
    sample_rate = 44100
    white_noise = generate_white_noise(duration_sec, sample_rate)

    # Scale to 16-bit integer range
    white_noise_scaled = np.int16(white_noise * 32767)

    # Write white noise to WAV file
    write("white_noise.wav", sample_rate, white_noise_scaled)
