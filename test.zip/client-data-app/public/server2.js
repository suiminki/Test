const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Store comments in an array
let comments = [];

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve HTML file for commenting
app.get('/comment', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'comment.html'));
});

// Endpoint to handle comment submission
app.post('/comment', (req, res) => {
  const newComment = req.body.comment;
  comments.push(newComment);
  res.redirect('/comment');
});

// Endpoint to retrieve comments
app.get('/comments', (req, res) => {
  res.json({ comments });
});

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Start the server
app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
