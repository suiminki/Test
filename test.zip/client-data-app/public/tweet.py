import tweepy
import random
import schedule
import time

# Define your Twitter API credentials
API_KEY = 'ifQGGpA1WhIPm1L0l1gOQAfjZ'
API_SECRET_KEY = 'ALqzxUwUrVAxQPCEOCBvwwApxIv0iUxMyuFwi9Q5ivn6adNczZ'
ACCESS_TOKEN = '1766125742893735936-rOiQIWJzDjzS01jHaH5lvLcC1jDsnI'
ACCESS_TOKEN_SECRET = 'MIMwfrv47qNOXvEQD8lxvpMxTRmZyPLThSZQEsJUrrCC6'

# Authenticate with Twitter API
auth = tweepy.OAuth1UserHandler(API_KEY, API_SECRET_KEY, ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
api = tweepy.API(auth)

# List of inspirational quotes
quotes = [
    "The only way to do great work is to love what you do. - Steve Jobs",
    "Believe you can and you're halfway there. - Theodore Roosevelt",
    "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
    "In the end, it's not the years in your life that count. It's the life in your years. - Abraham Lincoln",
    "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt"
]

# Function to tweet a random quote
def tweet_quote():
    quote = random.choice(quotes)
    api.update_status(quote)
    print("Tweeted:", quote)

# Schedule the tweet to occur daily
for day in range(365):
    day_str = str(day + 1)  # Convert day number to string
    schedule.every().day.at("08:00").do(tweet_quote).tag(day_str)  # Change the time as desired

# Main function to run the scheduler
if __name__ == "__main__":
    while True:
        schedule.run_pending()
        time.sleep(1)
