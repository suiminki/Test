const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const app = express(); //c
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const wsPort = 3000; // WebSocket server port
const httpPort = 3001; // HTTP server port

// Serve HTML file for uploading
app.get('/', (req, res) => {
  const indexPath = path.join(__dirname, 'public', 'index.html');
  console.log('Index HTML Path:', indexPath);
  console.log('Current Directory:', __dirname);//h
  
  // Check if the index.html file exists
  if (fs.existsSync(indexPath)) {
    // Send the index.html file if it exists
    res.sendFile(indexPath);
  } else {
    // Log an error if the file does not exist
    console.error('Error: index.html file not found');
    res.status(404).send('File Not Found');
  }//a
});

// Serve HTML file for displaying uploaded files
app.get('/uploaded-files', (req, res) => {
  fs.readdir('uploads', (err, files) => {
    if (err) {
      console.error('Error reading uploads directory:', err);
      res.status(500).send('Internal Server Error');
    } else {
      res.send(files); // Send the list of files as JSON//t
    }
  });
});

// Set up multer for handling file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/') // Save uploaded files to the 'uploads' directory
  },
  filename: function (req, file, cb) {//G
    cb(null, file.originalname) // Use the original filename
  }
});

// Create multer instance with defined storage
const upload = multer({ storage: storage });

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());//P
app.use(cookieParser());
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
}));

// Function to read user data from JSON file
function readUsersData() {
  try {
    const data = fs.readFileSync('users.json');
    return JSON.parse(data);
  } catch (error) {
    // If file doesn't exist or error reading file, return an empty array
    return [];
  }
}

// Function to write user data to JSON file
function writeUsersData(usersData) {//T
  fs.writeFileSync('users.json', JSON.stringify(usersData, null, 2));
}

// Routes
app.post('/login', (req, res) => {
  const { username, password, Email } = req.body;

  // Read existing user data from JSON file
  const usersData = readUsersData();

  // Check if the username and password match any user in the data
  const user = usersData.find(user => user.username === username && user.password === password );
  if (user) {
    // Store user session
    req.session.user = user;
    res.send({ message: "Login successful", username , password });

  } else {
    res.status(401).send({ error: "Invalid username or password" });
  }
});


// Function to write comments to JSON file
function writeCommentsData(commentsData) {
  fs.writeFileSync('comments.json', JSON.stringify(commentsData, null, 2));
}

// Endpoint to handle comment submission
app.post('/comment', (req, res) => {
  // Check if the user is logged in
  if (!req.session || !req.session.user) {
    return res.status(401).send({ error: "Unauthorized" });
  }

  const { comment } = req.body;
  const username = req.session.user.username; // Retrieve username from the session
  const timestamp = new Date().toLocaleString(); // Get current timestamp
  
  // Store the comment along with the username and timestamp
  comments.push({ username, comment, timestamp });
  
  // Write the updated comments data back to the JSON file
  writeCommentsData(comments);

  // Redirect the user back to the comment page
  res.redirect('/comment');
});


app.post('/signup', (req, res) => {
  const { username, email, password } = req.body;

  // Read existing user data from JSON file
  let usersData = readUsersData();

  // Check if the username or email already exists
  const existingUser = usersData.find(user => user.username === username || user.email === email);
  if (existingUser) {
    return res.status(400).send({ error: "Username or email already exists" });
  }

  // Add the new user to the array
  usersData.push({ username, email, password });

  // Write the updated user data back to the JSON file
  writeUsersData(usersData);

  res.send({ message: "User created successfully" });
});

app.get('/signup', (req, res) => {
  const { username, email, password } = req.body;
  res.send({ message: "User created successfully",username, email, password });
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.send({ message: "Logout successful" });
});

app.delete('/account', (req, res) => {
  // Check if user session exists
  if (!req.session || !req.session.user) {
    return res.status(401).send({ error: "Unauthorized" });
  }

  const username = req.session.user.username;

  // Read existing user data from JSON file
  let usersData = readUsersData();

  // Find the index of the user to delete
  const userIndex = usersData.findIndex(user => user.username === username);

  // If user not found, return error
  if (userIndex === -1) {
    return res.status(404).send({ error: "User not found" });
  }

  // Remove the user from the array
  usersData.splice(userIndex, 1);

  // Write the updated user data back to the JSON file
  writeUsersData(usersData);

  // Destroy user session
  req.session.destroy();

  res.send({ message: "Account deleted successfully" });
});
// Handle file upload
app.post('/upload', upload.single('file'), (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>File Upload Success</title>
    </head>
    <body>
      <h1>File Upload Successful</h1>
      <p>Your file has been uploaded successfully.</p>
      <a href="/">Back to Upload Page</a>
    </body>
    </html>
  `);
});
// Serve uploaded files
app.get('/uploads/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, 'uploads', filename);
  res.sendFile(filePath);
});
// Store comments in an array with username and timestamp
let comments = [];
// Serve HTML file for commenting
app.get('/comment', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'comment.html'));
});
// Endpoint to retrieve comments
app.get('/comments', (req, res) => {
  res.json({ comments });
});
// Endpoint to handle comment submission
app.post('/comment', (req, res) => {
  // Check if the user is logged in
  if (!req.session || !req.session.user) {
    return res.status(401).send({ error: "Unauthorized" });
  }
  const { comment } = req.body;
  const username = req.session.user.username; // Retrieve username from the session
  const timestamp = new Date().toLocaleString(); // Get current timestamp
  
  // Store the comment along with the username and timestamp
  comments.push({ username, comment, timestamp });
  
  // Redirect the user back to the comment page
  res.redirect('/comment');
});
app.get('/loggedinuser', (req, res) => {
  if (req.session.user) {
    res.json({ username: req.session.user.username }); // Send the username if user is logged in
  } else {
    res.json({ username: null }); // Send null if no user is logged in
  }
});
// Endpoint to retrieve active users
app.get('/loggedinusers', (req, res) => {
  const loggedInUsers = Array.from(clients.keys()); // Extract usernames from connected clients
  res.json({ users: loggedInUsers });
});
app.use(express.static('public'));
// Store connected clients
const clients = new Map();
// WebSocket connection handler
// WebSocket connection handler
// WebSocket connection handler
wss.on('connection', function connection(ws, req) {
  const username = req.url.substring(1); // Extract username from URL
  clients.set(username, ws);

  broadcast(`${username} joined the chat`);

  ws.on('message', function incoming(message) {
    try {
      const parsedMessage = JSON.parse(message); // Parse the received message
      const sender = username; // Assuming sender is the username
      const content = parsedMessage.content; // Extract content from the parsed message
      const formattedMessage = JSON.stringify({ sender, content }); // Format the message

      clients.forEach(client => {
        if (client !== clients.get(sender)) {
          client.send(formattedMessage); // Send the formatted message
        }
      });
    } catch (error) {
      console.error('Error processing received message:', error);
    }
  });

  ws.on('close', function close() {
    clients.delete(username);
    broadcast(`${username} left the chat`);
  });
});
// Function to broadcast messages to all connected clients
function broadcast(message) {
  clients.forEach(client => {
    client.send(message);
  });
}
// Start HTTP server
server.listen(httpPort, () => {
  console.log(`HTTP server is listening at http://localhost:${httpPort}`);
});
// WebSocket server is already listening
console.log(`WebSocket server is listening at ws://localhost:${wsPort}`);
